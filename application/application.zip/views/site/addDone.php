<?php require_once 'template/pagesHeader.php'; ?>

<div class="container paypal_data center-block">
	<table class="table table-condensed">
		<tr class="success">
			<td class="text-center">تم الاشتراك بنجاح</td>
		</tr>
	</table>
</div>
<meta http-equiv="refresh" content="3;URL=<?php echo HOST_NAME . 'dashbord/'; ?>">

<?php require_once 'template/footer.php'; ?>