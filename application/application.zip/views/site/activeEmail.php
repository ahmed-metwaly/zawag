<?php require_once 'template/pagesHeader.php'; ?>





<div class="section-new-pages">
  <!-- section-new-pages -->
  <div class="container">
    <div class="row">
      <div class="message">
        <?php echo $message; ?>
      </div>
    </div>
  </div>
</div>
<!-- end section-new-pages -->


<?php require_once 'template/footer.php'; ?>