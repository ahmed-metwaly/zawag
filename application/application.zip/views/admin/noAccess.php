<?php require_once 'template/header.php'; ?>
    <div class="alert alert-warning alert-dismissable" style="text-align: center;">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>

        عفوا ليس لديك صلاحية لرؤية هذه الصفحة

        <a href="" class="alert-link"></a>
    </div>
<?php require_once 'template/footer.php'; ?>

<?php die(); ?>